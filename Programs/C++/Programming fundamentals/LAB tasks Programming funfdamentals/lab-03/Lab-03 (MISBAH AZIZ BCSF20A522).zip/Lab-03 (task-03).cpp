#include <iostream>
using namespace std;
int main()
{ 
	cout<<"                    *\n";
	cout<<"                   ***\n";
	cout<<"                  *****\n";
	cout<<"                 *******\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"                    *\n";
	cout<<"\n";
	cout<<"Press enter key to continue";
	return 0;
}
