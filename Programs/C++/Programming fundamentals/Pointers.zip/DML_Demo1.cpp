
#include<iostream>
using namespace std;

int main()	
{
/*
	int *ptr = nullptr;
	
	ptr = new int;
	
	cin >> *ptr;
	
	cout << "The value is : " << *ptr << endl;
	
	delete ptr;
*/	


	int *ptr = nullptr;
	int size;
	
	cout << "Please enter the count of students in your class: " ;
	cin >> size;
	
	ptr = new int[size];
	
	cout << ptr;
	
	for(int i=0; i<size; i++)
	{
		cout << "Please enter marks for student " << i+1 << ": " ;
		cin >> *(ptr+i);
	}
	
	
	
	delete [] ptr;
	ptr = nullptr;
	

	
	cout << "Program exiting........" << endl;
	return 0;
}





