

#include<iostream>
using namespace std;


int main()		// function defination / declaration
{

	short marks[] = {70, 90, 100, 30, 59};

	cout << marks << endl;
	cout << *marks << endl;
	
	cout << *(marks+2) << endl; 
	
	
	cout << "Program exiting........" << endl;
	return 0;
}





