
#include<iostream>
using namespace std;


int main()	
{

	int size = 5;
	int marks[size];

	// pointer variable
	int *ptr = marks;
	
	// initialize the array elements
	for (int i=0; i<size; i++)
	{
		cout << "Please enter value for index " << i << " :" ;
		cin >> *(ptr+i);		// ptr + 2 => ptr + 8
	}

	
	cout << endl << endl;
	
	// displaying array elements
	for (int i=0; i<size; i++)
	{
		cout << *(ptr+i) << "\t";		// ptr + 2 => ptr + 8
	}	
	
	
	cout << " \n\n ANOTHER WAY TO ACCESS ARRAY ELEMENTS " << endl;
	
	
	for (int i=0; i<size; i++)
	{
		cout << ptr[i] << "\t";		
	}	
	 
	
	cout << " \n\n ANOTHER WAY TO ACCESS ARRAY ELEMENTS " << endl;
		
	for (int i=0; i<size; i++)
	{
		ptr = &marks[i];
		cout << *ptr << "\t";		
	}
	
	
	cout << " \n\n ANOTHER WAY TO ACCESS ARRAY ELEMENTS " << endl;
	
	ptr = marks;	
	for (int i=0; i<size; i++)
	{
		cout << *ptr << "\t";		
		ptr++;
	}
	
	cout << "Program exiting........" << endl;
	return 0;
}





