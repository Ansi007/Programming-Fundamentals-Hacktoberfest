
#include<iostream>
using namespace std;

// How to pass a pointer to a function as an argument

int* getProcessedData(int *data)
{	
		int* tmp = nullptr;   // OR new int;
		//*tmp = *data + 100;
		tmp = data;
		*tmp += 100;
		return tmp;
}

int main()	
{
	
	int *iptr = nullptr;
	int x = 100;
	iptr = &x;
	
	int* result = getProcessedData(iptr);
	cout << "The processed value : " << *result << endl;
	
	cout << "Program exiting........" << endl;
	return 0;
}





