
#include<iostream>
using namespace std;

// How to pass a pointer to a function as an argument

void getData(int *);
void processData(int *);
void showData(int *);

int main()	
{

	int data;
	
	getData(&data);
	
	cout << "\n The value of data : " ;
	showData(&data);
	
	
	processData(&data);
	
	cout << "\n The value of data after processing: " ;
	showData(&data);
	
	
	cout << "Program exiting........" << endl;
	return 0;
}

void getData(int *num)
{
	cout << "Please enter data : " ;
	cin >> *num;
}

void processData(int *val)
{
	*val = *val + 10;
}

void showData(int *number)
{
	cout << *number ;
}




