
#include<iostream>
using namespace std;

// How to pass a pointer to a function as an argument

void getData(int *arr , int size)
{
	for(int i=0; i< size; i++)
	{
		cout << "Please enter value for student " << i +1 << ": ";
		cin >> arr[i];  // *(arr+i) // *arr	
	}
}

void getAverage(int *arr , int size)
{
	int sum = 0;
	for(int i=0; i< size; i++)
	{
		sum = sum + arr[i];  
				//sum = sum + *arr;  
				//arr++;
		//sum = sum + *arr++;
	}
	
	int avg = sum/3;
	cout << "The average is : " << avg << endl;
}

int main()	
{
	int size = 3;
	int marks[size];
	

	getData(marks, size);	
	
	getAverage(marks, size);
	
	
	
	cout << "Program exiting........" << endl;
	return 0;
}





