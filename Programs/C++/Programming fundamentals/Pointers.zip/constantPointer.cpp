
#include<iostream>
using namespace std;

int main()	
{

	const int number = 6;
	
	const int* iptr = nullptr;
	
	iptr = &number;
	

	
	cout << "Program exiting........" << endl;
	return 0;
}





