

#include<iostream>
using namespace std;


int main()		// function defination / declaration
{
	int x;	// int (4 byte)
	x = 10;
	
	int y = 20;
	
	cout << "Value: " <<  x << endl;
	cout << "Address: " << &x << endl; // address of the meemory location where the value of x exst.
	
	// C++11
	// nullptr-> 0  OR Nothing
	int *ptr = nullptr;	// pointer-to-int OR interger pointer
	ptr = &x;
	
	cout << "Address using pointer : " << ptr << endl;
	cout << "Value using pointer : " << *ptr << endl;
	
	ptr = &y;
	
	cout << "Value using pointer after modification: " << *ptr << endl;
	
	
	cout << "Program exiting........" << endl;
	return 0;
}





