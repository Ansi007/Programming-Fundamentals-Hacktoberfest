#include <iostream>
using namespace std;
int main()
{
	double payAmount, payPeriods, annualPay;
	payAmount=2000,
	payPeriods = 12;
	annualPay = payAmount * payPeriods;
	cout<<endl<<endl;
	cout<<"Total annualPay is :"<<annualPay<<endl;
	cout<<endl<<endl;
	return 0;
}
