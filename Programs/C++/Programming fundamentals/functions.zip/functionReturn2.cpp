

#include<iostream>
using namespace std;

// prototype declaration
void div(int, int);		


int main()		
{
	int a, b;
	double result = 0.0;
	
	cout << "please enter values of two operands : " << endl;
	cin >> a >> b ;

	div(a, b);	

	cout << "Program exiting........" << endl;
	
	return 0;
}


void div(int num, int den)
{
	double qou = 0.0;
	if(den == 0)
	{
		cout << "Error: denominator cannot be entered as zero" << endl;
		return;
	}

	qou = ( static_cast<double>(num) )/den;			
		
	cout << "The result is : " << qou << endl;
	cout << "Exiting from Div()"  << endl;

}




