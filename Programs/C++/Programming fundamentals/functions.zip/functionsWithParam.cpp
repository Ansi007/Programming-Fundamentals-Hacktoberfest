

#include<iostream>
using namespace std;

// This function will accept two parametrs, add them and display their result.
void add(int x, int y) 			
{	
	int sum;
	x++;
	y++;
	cout << "x: " << x << endl; 	
	cout << "y: " << y << endl; 	
	sum =  x + y;
	cout << "The sum of two number is : " << sum << endl;
}
int main()		// function defination / declaration
{
	int a, b;
	cout << "Please enter two values of a and b : " ;
	cin >> a >> b;
	
	add(a, b);	//call 

	cout << "a: " << a << endl;
	cout << "b: " << b << endl;
	
	cout << "Program exiting........" << endl;
	return 0;
}





