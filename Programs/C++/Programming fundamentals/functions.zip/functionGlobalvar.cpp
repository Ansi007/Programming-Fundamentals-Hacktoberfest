

#include<iostream>
using namespace std;

const double pi = 3.14;

void Area(double radius)
{
	double val = pi;
	double area = pi * radius * radius;
	cout << "Area of circle is :" << area << endl;
}

int main()		
{	
	double rad;
	cout << "Please enter value of radius : " ;
	cin >> rad;
	
	Area(rad);
		
	cout << "Program exiting........" << endl;
	return 0;
}




