
#include<iostream>
using namespace std;

void Sum()
{
	cout << "No parametrized fucntion of Sum()" << endl;
	
	int x, y;
	cout << "Please enter two values for x and y: " << endl;
	cin >> x >> y;
	
	int sum =  x + y;
	cout << "Sum : " << sum << endl;
}

void Sum(int x, int y)
{
	cout << "Two parametrized fucntion of Sum(int, int)" << endl;
	int sum =  x + y;
	cout << "Sum : " << sum;
}

void Sum(int x, int y, int z)
{
	cout << "Three parametrized fucntion of Sum(int, int, int)" << endl;
	int sum =  x + y + z;
	cout << "Sum : " << sum;
}

int main()		
{

	Sum();
	
	cout << "Control back to main()" << endl;
	
	Sum(10, 20); // two-param
	
	return 0;
}






