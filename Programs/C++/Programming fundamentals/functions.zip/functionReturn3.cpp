

#include<iostream>
using namespace std;

// prototype declaration
bool isValid(int);		


int main()		
{
	int marks;
	cout << "Please enter the marks of subject: " ;
	cin >> marks;
	
	if( isValid(marks) )
			cout << "The number is in the range " << endl;
	else
			cout << "Error: number is not in the range of 0 to 100 " << endl;

	cout << "Program exiting........" << endl;
	return 0;
}

bool isValid(int num)
{
	if(num<0 || num>100)		// marks 0-100
		return false;
	else
		return true;
		
}



