

#include<iostream>
using namespace std;
			
void showArea(double, double=10);


int main()		// function defination / declaration
{
	showArea(5);
	
	
	return 0;
}


void showArea(double length, double width)
{
	double area = length * width;
	cout << "The area is " << area << endl;
}
