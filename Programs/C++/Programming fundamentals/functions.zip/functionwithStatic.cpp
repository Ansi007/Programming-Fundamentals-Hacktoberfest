
#include<iostream>
using namespace std;

void Process()
{
	cout << "Control enters into Process() " << endl;
	static int x = 0;
	x++;
	x++;
	
	cout << "X : " << x << endl;
}


int main()		
{

	
	Process();  // x =2
	Process();
		
	return 0;
}






