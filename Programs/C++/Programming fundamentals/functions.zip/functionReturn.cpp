

#include<iostream>
using namespace std;

// prototype declaration
int add(int, int);	
int sub(int , int);
double div(double, int);		
void showOutput(double);

int main()		// function defination / declaration
{
	//double result = div(10.0, 3);
	//showOutput(result);

	showOutput( div(10.0, 2) );		//showOutput( 5 );
	
	cout << "Program exiting........" << endl;
	
	return 0;
}

void showOutput(double val)
{
	double result = val * val;
	cout << "The result is : " << result << endl;
}

double div(double num, int den)
{
	double qou;
	qou = num/den;		
	return qou;
}

int add(int x, int y) 			// function defination / declaration
{
	int sum;				// local variables
	sum =  x + y;
	return sum;
}

int sub(int x, int y)			// function defination / declaration
{
	int sub;
	sub = x - y;
	return sub;
}



