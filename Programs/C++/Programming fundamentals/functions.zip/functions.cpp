

#include<iostream>
using namespace std;

// prototype declaration
void add();	
void sub();		

void show()
{
	cout << "Control enters into show()" << endl;
}


int main()		// function defination / declaration
{
	int choice;
	
	do
	{
		cout << "\n\n Please enter 1 for add \n 2 for subtraction \n -99 for exit" << endl;
		cin >> choice;
		
		if(choice != -99)
		{
			switch(choice)
			{
				case 1: 
						add();
						break;
				case 2:
						sub();
						break;
				default:
						cout << "Invalid choice." << endl;
						break;	
			}
		}
		
	}while(choice != -99);
	

	cout << "Program exiting........" << endl;
	
	return 0;
}

void add() 			// function defination / declaration
{
	cout << "Control enters into add()" << endl;
	
	show();		// call
		
	
	int x, y, sum;				// local variables
	cout << "Please enter two values x and y: ";
	cin >> x >> y;
	sum =  x + y;
	cout << "The sum of two number is : " << sum << endl;
}

void sub()			// function defination / declaration
{
	int x, y, sub;
	cout << "Please enter two values x and y: ";
	cin >> x >> y;
	sub = x - y;
	cout << "The subtaction of two number is : " << sub << endl;
}



