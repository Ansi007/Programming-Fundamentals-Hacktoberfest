

#include<iostream>
using namespace std;

void process(int &val)
{	
	val++;	
}

int main()		
{	
	int val = 10;
	cout << "The number is : " << val;		// 10
	
	process(val);
	
	cout << "The number is : " << val;		// ?
		
	return 0;
}




