

#include<iostream>
using namespace std;

// prototype declaration
double div(int, int);		
void showOutput(double);

int main()		
{
	int a, b;
	double result = 0.0;
	
	cout << "please enter values of two operands : " << endl;
	cin >> a >> b ;

	result = div(a, b);
	
	showOutput(result);
	
	
	cout << "Program exiting........" << endl;
	
	return 0;
}


double div(int num, int den)
{
	double qou = 0.0;
	if(den == 0)
	{
		cout << "Error: denominator cannot be entered as zero" << endl;
		return 0.0;
	}
	else
	{
		qou = ( static_cast<double>(num) )/den;			
	}
	cout << "Before exiting div()" << endl;
	return qou;
}


void showOutput(double val)
{
	cout << "The result is : " << val << endl;
}


